"""Carga configuración privada antes de importar el motor. Sin claves ni cambios remotos."""
import json, sys, re
from pathlib import Path
from urllib.parse import urlsplit
ROOT=Path(__file__).resolve().parent
DEFAULT=ROOT/'config_base_v200.json'

def read(p): return json.loads(Path(p).read_text(encoding='utf-8-sig'))
def write(p,obj): Path(p).write_text(json.dumps(obj,ensure_ascii=False,indent=2)+'\n',encoding='utf-8')
def req(ok,msg):
    if not ok: raise ValueError(msg)
def valid_url(s):
    if not isinstance(s,str): return False
    u=urlsplit(s)
    return u.scheme=='https' and bool(u.hostname) and not u.username and not u.password and not u.fragment

def validate(c, base):
    req(isinstance(c,dict) and c.get('version')==1,'Versión de configuración no admitida')
    req(set(c)==set(base),'Campos de configuración incorrectos')
    topics=c['temas']; req(isinstance(topics,dict) and set(topics)==set(base['temas']),'Secciones de temas incorrectas')
    for sec, ts in topics.items():
        req(isinstance(ts,dict) and len(ts)<=500,'Temas inválidos en '+sec)
        for name,prio in ts.items():req(isinstance(name,str) and 0<len(name.strip())<=160 and prio in ('alta','media','aleatoria','desactivada'),'Tema/prioridad inválidos en '+sec)
    req(topics['El Gabinete']==base['temas']['El Gabinete'],'Los temas de El Gabinete siguen protegidos')
    sources=c['fuentes']; req(isinstance(sources,list) and len(sources)<=100,'Lista de fuentes inválida')
    originals={s['nombre']:s for s in base['fuentes']}; names=set()
    allowed=set(base['temas'])|{'Nature'}
    for s in sources:
        req(isinstance(s,dict) and set(s)=={'nombre','seccion','secciones','url','rss_preferido','activo','protegido'},'Campos de fuente inválidos')
        n=s['nombre']; req(isinstance(n,str) and 0<len(n.strip())<=100 and n.casefold() not in names,'Fuente duplicada o sin nombre'); names.add(n.casefold())
        req(type(s['activo']) is bool and type(s['protegido']) is bool,'Estado de fuente inválido')
        if n in originals and originals[n]['protegido']:
            req(s==originals[n],'Fuente especial protegida: '+n)
        else:
            req(not s['protegido'],'No se puede crear una fuente protegida')
            req(n not in ('Xataka Móvil','Computer Hoy','IMDb','The Hollywood Reporter'),'Fuente especial reservada: '+n)
            if s!=originals.get(n):
                req(valid_url(s['url']) and (not s['rss_preferido'] or valid_url(s['rss_preferido'])),'URL HTTPS inválida: '+n)
        req(s['seccion'] in allowed|{'Varios'} and isinstance(s['secciones'],list) and s['secciones'] and all(x in allowed for x in s['secciones']),'Sección de fuente inválida: '+n)
    for n,s in originals.items():
        if s['protegido']:req(n.casefold() in names and s in sources,'Falta fuente especial: '+n)
    req(any(s['activo'] for s in sources),'No hay fuentes activas')
    videos=c['videos']; req(isinstance(videos,dict) and set(videos)==set(base['videos']),'Secciones de vídeo inválidas')
    # Fase 2: mismos huecos y reglas de coordinación; candidatos editables.
    modes={'latest','latest_old','random','random_latest','last10','last10_old'}
    for sec, slots in videos.items():
        original=base['videos'][sec]
        req(isinstance(slots,list) and len(slots)==len(original),'Número de huecos modificado: '+sec)
        for i,(slot,old) in enumerate(zip(slots,original)):
            req(isinstance(slot,dict) and set(slot)=={'label','candidates'},'Campos de hueco incorrectos')
            req(slot['label']==old['label'],'No se pueden cambiar las etiquetas de hueco')
            candidates=slot['candidates']
            req(isinstance(candidates,list) and 1<=len(candidates)<=30,'El hueco debe tener entre 1 y 30 canales')
            for cand in candidates:
                req(isinstance(cand,dict) and {'channel','query','match','topic','max_months','mode','translate_title'} <= set(cand) and set(cand) <= {'channel','query','match','topic','max_months','mode','translate_title','max_days','min_minutes','preferred_days','topic_preference'},'Campos de canal incorrectos')
                for field in ('channel','query'):
                    value=cand[field]
                    req(isinstance(value,str) and 1<=len(value.strip())<=200,'Nombre o búsqueda inválidos')
                for field in ('match','topic'):
                    arr=cand[field]
                    req(isinstance(arr,list) and len(arr)<=20 and all(isinstance(x,str) and 0<len(x.strip())<=160 for x in arr),'Filtros inválidos: '+field)
                req(len(cand['match'])>=1,'Cada canal necesita una coincidencia verificable de autor')
                req(type(cand['max_months']) is int and 0<=cand['max_months']<=120,'Antigüedad inválida')
                req(cand['mode'] in modes,'Modo de rotación inválido')
                req(type(cand['translate_title']) is bool,'Traducción inválida')
    # La selección cruzada de Alán Barroso y La Base depende de estas posiciones.
    req(videos['gabinete']==base['videos']['gabinete'],'El Gabinete conserva su coordinación especial')
    return c

def apply(c):
    write(ROOT/'prioridades.json',{sec:{k:v for k,v in ts.items() if v!='desactivada'} for sec,ts in c['temas'].items()})
    write(ROOT/'fuentes_recopilacion_v200.json',c['fuentes'])
    # El selector real de vídeos importa este archivo, no el JSON legado.
    write(ROOT/'video_slots_v166.json',c['videos'])

if __name__=='__main__':
    base=read(DEFAULT); target=Path(sys.argv[1]); c=read(target) if target.is_file() else base
    validate(c,base); apply(c)
    print('Configuración editorial:', 'privada' if target.is_file() else 'base (sin archivo privado)')
    print('Temas activos:',sum(v!='desactivada' for ts in c['temas'].values() for v in ts.values()),'· Fuentes activas:',sum(s['activo'] for s in c['fuentes']))

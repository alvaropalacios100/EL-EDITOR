"""Prepare a public delivery ledger; send only after successful Pages deployment."""
import datetime as dt
import json, os, re, sys, uuid
from pathlib import Path
from urllib.request import Request, urlopen
from urllib.error import HTTPError

BASE='https://alvaropalacios100.github.io/EL-EDITOR/'
APP='806d2657-187f-471e-9e5d-0a3a8583ca9c'
STATE='push-state-v192.json'
NOW=dt.datetime.now(dt.timezone.utc)

def fetch_state():
    try:
        with urlopen(Request(BASE+STATE+'?run='+os.environ.get('GITHUB_RUN_ID','local'),headers={'Cache-Control':'no-cache'}),timeout=30) as r:
            return json.load(r)
    except HTTPError as e:
        if e.code==404:return None
        raise

def articles(site):
    s=(site/'index.html').read_text(); result={}
    for constant,prefix in [('EDITORIALES','EDITORIAL'),('CINEMATOGRAFO','ANÁLISIS')]:
        m=re.search(r'\bconst '+constant+r'\s*=\s*',s)
        if not m:raise ValueError('Falta '+constant)
        rows=json.JSONDecoder().raw_decode(s[m.end():])[0]
        for a in rows:
            url=a['url']
            if not re.fullmatch(r'[A-Za-z0-9_-]+\.html',url) or not (site/url).is_file():raise ValueError('Artículo sin página pública: '+url)
            result[url]={'title':prefix+': '+a['title'],'url':url}
    return result

def prepare(site,previous):
    current=articles(site)
    if previous is None:
        state={'seen':sorted(current),'queue':{}}
        print('Primera ejecución: artículos existentes registrados sin notificar.')
    else:
        seen=set(previous['seen']); queue={k:v for k,v in previous['queue'].items() if NOW-dt.datetime.fromisoformat(v['created'])<dt.timedelta(days=7) and k in current}
        for k in current.keys()-seen:
            queue[k]={**current[k],'created':NOW.isoformat(),'id':str(uuid.uuid5(uuid.NAMESPACE_URL,BASE+k))}
        state={'seen':sorted(seen|current.keys()),'queue':queue}
    (site/STATE).write_text(json.dumps(state,ensure_ascii=False,indent=2))
    return state

def send(site):
    key=os.environ['ONESIGNAL_API_KEY']; state=json.loads((site/STATE).read_text())
    for a in state['queue'].values():
        # OneSignal requires contents; use the full requested title as the body, no subtitle.
        payload={'app_id':APP,'included_segments':['Subscribed Users'],'target_channel':'push','contents':{'en':a['title'],'es':a['title']},'url':BASE+a['url'],'idempotency_key':a['id']}
        req=Request('https://api.onesignal.com/notifications',data=json.dumps(payload).encode(),headers={'Authorization':'Key '+key,'Content-Type':'application/json'},method='POST')
        with urlopen(req,timeout=30) as r: result=json.load(r)
        if not result.get('id'):raise RuntimeError('OneSignal no confirmó el envío: '+a['url'])
        print('OneSignal confirmó:',a['url'])

if __name__=='__main__':
    site=Path(sys.argv[2]); mode=sys.argv[1]
    if mode=='prepare':prepare(site,fetch_state())
    elif mode=='send':send(site)
    else:raise ValueError(mode)
